<!-- Incluímos la conexión a base de datos -->
<?php 
    include 'connection.php';
?>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <meta name="Description" content="Enter your description here"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
        <!-- CUSTOM CSS -->
        <link rel="stylesheet" href="CSS/styles.css">
        <!-- Custom Favicon -->
        <link rel="shortcut icon" href="IMG/favicon.jpg" type="image/x-icon">
        <!-- CDN Font Awesome -->
        <script src="https://kit.fontawesome.com/857f3fe573.js" crossorigin="anonymous"></script>
        <title>Editar Reserva</title>
    </head>
    <body>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
            <div class="container">
                <a href="index.php" class="navbar-brand">Portal Restaurante Bootstrap</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <!-- Menu de navegación -->
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="index.php#reservations">Volver a Inicio</a>
                        </li>
                        <li class="nav-item disabled">
                            <a class="nav-link" href="buscarReserva.php">Buscar Reserva</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="container p-4">
            <div class="row">
                <div class="col-md-4 mx-auto">
                    <div class="card card-body">
                        <form action="listaReservas.php" method="POST">
                            <p class="text-center">Llena los datos a continuación para editar tus reservas <i class="fas fa-hand-point-down"></i></p>
                            <div class="form-group">
                                <label for="nombre">Nombre(s):</label>
                                <input type="text" class="form-control" name="nombre" placeholder="Nombre(s)" autofocus>
                            </div>
                            <div class="form-group">
                            <label for="apellido">Apellidos:</label>
                                <input type="text" class="form-control" name="apellido" placeholder="Apellidos">
                            </div>
                            <input type="submit" class="btn btn-success btn-block" name="search" value="Search">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>