//Creamos una variable que busque un elemento llamado "boton" y le asignamos una funcion
var menuOne = document.getElementById("menuOne");
var menuTwo = document.getElementById("menuTwo");
var menuThree = document.getElementById("menuThree");
var menuFour = document.getElementById("menuFour");
var menuFive = document.getElementById("menuFive");
var menuSix = document.getElementById("menuSix");
var itemOne = "";
var itemTwo = "";
var itemThree = "";
var nombre = "";
var direccion = "";
var price = 0;
var recibido = 0;
var vueltosCliente = 0;
//var confirmation = confirm("¿Desea agregar algo?");
menuOne.addEventListener("click", function(){
    itemOne = "1 Pollo asado";
    itemTwo = "Porción de papas a la francesa";
    itemThree = "1 gaseosa litro de su preferencia";
    price = 200.0;
    alert("Menú Uno"+"\n"+
    "Item 1: "+itemOne+"\n"+
    "Item 2: "+itemTwo+"\n"+
    "Item 3: "+itemThree+"\n"+
    "Precio: $"+price);
    nombre = prompt("Ingrese su nombre");
    direccion = prompt("Ingrese su dirección");
    recibido = prompt("Ingrese el monto recibido");
    vueltosCliente = recibido - price;
    alert("Gracias por su compra: "+nombre+"\n"+
        "Su pedido será enviado a: "+direccion+"\n"+
        "Sus vueltos son: "+vueltosCliente);
    //alert("Su pedido será enviado a: "+direccion);
    var confirmation = confirm("¿Desea continuar con el pedido?");
    if(confirmation == true){
        alert("Pedido realizado");
    }
    else{
        alert("Pedido cancelado");
    }
});
menuTwo.addEventListener("click", function(){
    itemOne = "1 Pollo asado";
    itemTwo = "Porción de papas a la francesa";
    itemThree = "1 gaseosa litro de su preferencia";
    price = 200.0;
    alert("Menú Uno"+"\n"+
    "Item 1: "+itemOne+"\n"+
    "Item 2: "+itemTwo+"\n"+
    "Item 3: "+itemThree+"\n"+
    "Precio: $"+price);
    nombre = prompt("Ingrese su nombre");
    direccion = prompt("Ingrese su dirección");
    recibido = prompt("Ingrese el monto recibido");
    vueltosCliente = recibido - price;
    alert("Gracias por su compra: "+nombre+"\n"+
        "Su pedido será enviado a: "+direccion+"\n"+
        "Sus vueltos son: "+vueltosCliente);
    
    //alert("Su pedido será enviado a: "+direccion);
    var confirmation = confirm("¿Desea continuar con el pedido?");
    if(confirmation == true){
        alert("Pedido realizado");
    }
    else{
        alert("Pedido cancelado");
    }
});
menuThree.addEventListener("click", function(){
    itemOne = "1 Pollo asado";
    itemTwo = "Porción de papas a la francesa";
    itemThree = "1 gaseosa litro de su preferencia";
    price = 200.0;
    alert("Menú Uno"+"\n"+
    "Item 1: "+itemOne+"\n"+
    "Item 2: "+itemTwo+"\n"+
    "Item 3: "+itemThree+"\n"+
    "Precio: $"+price);
    nombre = prompt("Ingrese su nombre");
    direccion = prompt("Ingrese su dirección");
    recibido = prompt("Ingrese el monto recibido");
    vueltosCliente = recibido - price;
    alert("Gracias por su compra: "+nombre+"\n"+
        "Su pedido será enviado a: "+direccion+"\n"+
        "Sus vueltos son: "+vueltosCliente);
    
    //alert("Su pedido será enviado a: "+direccion);
    var confirmation = confirm("¿Desea continuar con el pedido?");
    if(confirmation == true){
        alert("Pedido realizado");
    }
    else{
        alert("Pedido cancelado");
    }
});
menuFour.addEventListener("click", function(){
    itemOne = "1 Pollo asado";
    itemTwo = "Porción de papas a la francesa";
    itemThree = "1 gaseosa litro de su preferencia";
    price = 200.0;
    alert("Menú Uno"+"\n"+
    "Item 1: "+itemOne+"\n"+
    "Item 2: "+itemTwo+"\n"+
    "Item 3: "+itemThree+"\n"+
    "Precio: $"+price);
    nombre = prompt("Ingrese su nombre");
    direccion = prompt("Ingrese su dirección");
    recibido = prompt("Ingrese el monto recibido");
    vueltosCliente = recibido - price;
    alert("Gracias por su compra: "+nombre+"\n"+
        "Su pedido será enviado a: "+direccion+"\n"+
        "Sus vueltos son: "+vueltosCliente);
    
    //alert("Su pedido será enviado a: "+direccion);
    var confirmation = confirm("¿Desea continuar con el pedido?");
    if(confirmation == true){
        alert("Pedido realizado");
    }
    else{
        alert("Pedido cancelado");
    }
});
menuFive.addEventListener("click", function(){
    itemOne = "1 Pollo asado";
    itemTwo = "Porción de papas a la francesa";
    itemThree = "1 gaseosa litro de su preferencia";
    price = 200.0;
    alert("Menú Uno"+"\n"+
    "Item 1: "+itemOne+"\n"+
    "Item 2: "+itemTwo+"\n"+
    "Item 3: "+itemThree+"\n"+
    "Precio: $"+price);
    nombre = prompt("Ingrese su nombre");
    direccion = prompt("Ingrese su dirección");
    recibido = prompt("Ingrese el monto recibido");
    vueltosCliente = recibido - price;
    alert("Gracias por su compra: "+nombre+"\n"+
        "Su pedido será enviado a: "+direccion+"\n"+
        "Sus vueltos son: "+vueltosCliente);
    
    //alert("Su pedido será enviado a: "+direccion);
    var confirmation = confirm("¿Desea continuar con el pedido?");
    if(confirmation == true){
        alert("Pedido realizado");
    }
    else{
        alert("Pedido cancelado");
    }
});
menuSix.addEventListener("click", function(){
    itemOne = "1 Pollo asado";
    itemTwo = "Porción de papas a la francesa";
    itemThree = "1 gaseosa litro de su preferencia";
    price = 200.0;
    alert("Menú Uno"+"\n"+
    "Item 1: "+itemOne+"\n"+
    "Item 2: "+itemTwo+"\n"+
    "Item 3: "+itemThree+"\n"+
    "Precio: $"+price);
    nombre = prompt("Ingrese su nombre");
    direccion = prompt("Ingrese su dirección");
    recibido = prompt("Ingrese el monto recibido");
    vueltosCliente = recibido - price;
    alert("Gracias por su compra: "+nombre+"\n"+
        "Su pedido será enviado a: "+direccion+"\n"+
        "Sus vueltos son: "+vueltosCliente);
    //alert("Su pedido será enviado a: "+direccion);
    var confirmation = confirm("¿Desea continuar con el pedido?");
    if(confirmation == true){
        alert("Pedido realizado");
    }
    else{
        alert("Pedido cancelado");
    }
});

