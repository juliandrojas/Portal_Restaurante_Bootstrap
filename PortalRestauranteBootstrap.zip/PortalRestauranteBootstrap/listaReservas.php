<?php
    //Include the connection file
    include 'connection.php';
    $nombreCliente = "";
    $apellidoCliente = "";
    //Generate the table of reservations
    if(isset($_POST['search'])) {
        $nombreCliente = $_POST['nombre'];
        $apellidoCliente = $_POST['apellido'];
        //echo "Nombre: $nombre <br>";
        //echo "Apellido: $apellido <br>";
    }
?>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <meta name="Description" content="Enter your description here"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
        <!-- CUSTOM CSS -->
        <link rel="stylesheet" href="CSS/styles.css">
        <!-- Custom Favicon -->
        <link rel="shortcut icon" href="IMG/favicon.jpg" type="image/x-icon">
        <!-- CDN Font Awesome -->
        <script src="https://kit.fontawesome.com/857f3fe573.js" crossorigin="anonymous"></script>
        <title>Lista de Reservas</title>
    </head>
    <body>
        <!-- Menú de navegación -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
            <div class="container">
                <a href="index.php" class="navbar-brand">Portal Restaurante Bootstrap</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <!-- Menu de navegación -->
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="index.php#reservations">Volver a Inicio</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="buscarReserva.php">Buscar Reserva</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <h1 class="text-center">LISTA DE RESERVAS</h1>
        <div class="container">
            <!-- Tabla de reservas -->
            <table class="table table-bordered">
                <!-- Cabecera de la tabla -->
                <thead>
                    <tr class="text-center">
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Acompañantes</th>
                        <th>Fecha de la reserva</th>
                        <th>Hora de la reserva</th>
                        <th>Observaciones</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <!-- Cuerpo de la tabla -->
                <tbody>
                    <?php
                        //Consulta a la base de datos
                        $query = "SELECT * FROM reservas WHERE nombreCliente LIKE '$nombreCliente' AND apellidoCliente LIKE '$apellidoCliente'";
                        //Ejecutamos la consulta
                        $result = mysqli_query($connection, $query);
                        //Iteramos todas las filas de la tabla
                        while ($row = mysqli_fetch_array($result)) {?>
                            <!-- Mostramos los resultados de la consulta -->
                            <tr class="text-center">
                                <!-- Parte dinámica de la tabla -->
                                <td><?php echo $row['nombreCliente']?></td>
                                <td><?php echo $row['apellidoCliente']?></td>
                                <td><?php echo $row['acompañantes']?></td>
                                <td><?php echo $row['fechaReserva']?></td>
                                <td><?php echo $row['horaReserva']?></td>
                                <td><?php echo $row['observaciones']?></td>
                                <td>
                                    <!-- Editar reserva -->
                                    <a href="editarReserva.php?id=<?php echo $row['id']?>" class="btn btn-secondary"><i class="fas fa-marker"></i></a>
                                    <!-- Eliminar reserva -->
                                    <a href="eliminarReserva.php?id=<?php echo $row['id']?>" class="btn btn-danger"><i class="fas fa-trash-alt"></i></a>
                                </td>
                            </tr>
                    <?php } ?> 
                </tbody>
            </table>
        </div>
    </body>
</html>