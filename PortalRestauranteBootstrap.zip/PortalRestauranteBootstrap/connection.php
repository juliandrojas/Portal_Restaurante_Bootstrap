<?php
    //Guardamos credenciales de acceso
    //session_start();
    //Variable conexión
    $connection = mysqli_connect(
        'localhost',
        'root',
        '',
        'portal_restaurante'
    );
    //Verificamos conexión
    /*
    if(isset($connection)){
        echo "Connect!";
    }
    else {
        echo "Error!";
    }
    */
?>