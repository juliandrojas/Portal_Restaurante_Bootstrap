<?php 
    //Incluimos la conexión a la base de datos
    include('connection.php');
    //Comprobamos si se ha enviado el formulario
    if(isset($_GET['id'])) {
        //Si se ha enviado el formulario, guardamos el id en una variable
        $id = $_GET['id'];
        //Realizamos la consulta para obtener los datos del registro
        $query = "SELECT * FROM reservas WHERE id = $id";
        $result = mysqli_query($connection, $query);
        //Validamos si existe el id
        if (mysqli_num_rows($result) == 1) {
            //Si existe el id, guardamos los datos en una variable
            $row = mysqli_fetch_array($result);
            //Guardamos los datos en variables
            $acompañantes = $row['acompañantes'];
            $fechaReserva = $row['fechaReserva'];
            $horaReserva = $row['horaReserva'];
            $observaciones = $row['observaciones'];
            /*echo "acompañantes: $acompañantes" . "<br>";
            echo "fechaReserva: $fechaReserva" . "<br>";
            echo "horaReserva: $horaReserva" . "<br>";
            echo "observaciones: $observaciones" . "<br>";*/
        }
    }
?>
<?php
//Validamos si se ha enviado el formulario
    if(isset($_POST['actualizar'])){
        //Guardamos los datos en variables
        $id = $_GET['id'];
        $acompañantes = $_POST['acompañantes'];
        $fechaReserva = $_POST['fechaReserva'];
        $horaReserva = $_POST['horaReserva'];
        $observaciones = $_POST['observaciones'];
        //echo "id: $id" . "<br>";
        //echo "acompañantes: $acompañantes" . "<br>";
        //echo "fechaReserva: $fechaReserva" . "<br>";
        //echo "horaReserva: $horaReserva" . "<br>";
        //echo "observaciones: $observaciones" . "<br>";
        //Escribimos la consulta
        $query = "UPDATE reservas SET acompañantes = '$acompañantes', fechaReserva = '$fechaReserva', horaReserva = '$horaReserva', observaciones = '$observaciones' WHERE id = $id";
        //Ejecutamos la consulta
        $result = mysqli_query($connection, $query);
        //Validamos si se ha actualizado
        if($result){
            //Si se ha actualizado, alertamos
            echo "<script>alert('Reserva actualizada correctamente');</script>";
            //Redireccionamos a la página de lista de reservas
            echo "<script>window.location.href='buscarReserva.php';</script>";
        }
    }
?>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <meta name="Description" content="Enter your description here"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
        <!-- CUSTOM CSS -->
        <link rel="stylesheet" href="CSS/styles.css">
        <!-- Custom Favicon -->
        <link rel="shortcut icon" href="IMG/favicon.jpg" type="image/x-icon">
        <title>Portal Restaurante</title>
    </head>
    <body>
        <!-- Menú de navegación -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
            <div class="container">
                <a href="index.php" class="navbar-brand">Portal Restaurante Bootstrap</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <!-- Menu de navegación -->
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="index.php#reservations">Volver a Inicio</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="buscarReserva.php">Buscar Reserva</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Cramos un formulario para poder actualizar los datos -->
        <div class="container p-4">
            <div class="row">
                <div class="col-md-4 mx-auto">
                    <div class="card card-body">
                        <form action="editarReserva.php?id=<?php echo $_GET['id'];?>" method="POST">
                            <div class="form-group">
                                <input type="text" name="acompañantes" value="<?php echo $acompañantes;?>" class="form-control" placeholder="Actualizar Acompañantes">
                            </div>
                            <div class="form-group">
                                <input type="text" name="fechaReserva" value="<?php echo $fechaReserva;?>" class="form-control" placeholder="Actualizar Fecha">
                            </div>
                            <div class="form-group">
                                <input type="text" name="horaReserva" value="<?php echo $horaReserva;?>" class="form-control" placeholder="Actualizar Hora">
                            </div>
                            <div class="form-group">
                                <textarea name="observaciones" rows="2" class="form-control" placeholder="Actualizar Observaciones"><?php echo $observaciones;?></textarea>
                            </div>
                            <button class="btn btn-success btn-block mx-auto" name="actualizar">
                                Actualizar reserva
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Custom JS -->
        <script src="JS/main.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.slim.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.1/umd/popper.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/js/bootstrap.min.js"></script>