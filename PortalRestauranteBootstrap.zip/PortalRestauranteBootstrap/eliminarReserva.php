<?php
    //Incluimos la conexión a la base de datos
    include("connection.php");
    if(isset($_GET['id'])) {
        //Si existe la variable id, la guardamos en una variable
        $id = $_GET['id'];
        //Escribimos la consulta
        $query = "DELETE FROM reservas WHERE id = $id";
        $result = mysqli_query($connection, $query);
        //Alertamos sobre la eliminación
        echo "<script>alert('Reserva eliminada correctamente');</script>";
        //Redireccionamos a la página de lista de reservas
        echo "<script>window.location.href='buscarReserva.php';</script>";
    }
?>