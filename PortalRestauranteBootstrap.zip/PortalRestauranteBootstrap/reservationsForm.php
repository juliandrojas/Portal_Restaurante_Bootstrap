<?php
  //Include the connection file
  include 'connection.php';
    //Save the reservation
    if(isset($_POST['reservation'])){
      $nombreCliente = $_POST['nombreCliente'];
      $apellidoCliente = $_POST['apellidoCliente'];
      $correoCliente = $_POST['correoCliente'];
      $correoConfirmacion = $_POST['correoConfirmacion'];
      $telefono = $_POST['telefono'];
      $acompañantes = $_POST['acompañantes'];
      $fechaReserva = $_POST['fechaReserva'];
      $horaReserva = $_POST['horaReserva'];
      $observaciones = $_POST['observaciones'];
      //Imprimimos las variables
      /*
      echo $nombreCliente . '<br>';
      echo $apellidoCliente . '<br>';
      echo $correoCliente . '<br>';
      echo $correoConfirmacion . '<br>';
      echo $telefono . '<br>';
      echo $acompañantes . '<br>';
      echo $fechaReserva . '<br>';
      echo $horaReserva . '<br>';
      echo $observaciones . '<br>';
      */
      //Insertamos los datos
      $sql = "INSERT INTO reservas (nombreCliente, apellidoCliente, correoCliente, telefono, acompañantes, fechaReserva, horaReserva, observaciones) VALUES ('$nombreCliente', '$apellidoCliente', '$correoCliente', '$telefono', '$acompañantes', '$fechaReserva', '$horaReserva', '$observaciones')";
      //Ejecutamos la inserción
      $result = mysqli_query($connection, $sql);
      //Avisamos que se ha guardado
      echo "<script>alert('Reserva guardada con éxito');</script>";
      //Redireccionamos a la página de lista de reservas
      echo "<script>window.location.href='index.php#reservations';</script>";
    }
?>